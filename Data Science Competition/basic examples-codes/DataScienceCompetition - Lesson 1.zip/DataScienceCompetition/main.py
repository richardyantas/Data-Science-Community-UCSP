import pandas as pd
my_series = pd.Series([5,6,7,8,9,10])
my_series